#include "pico/stdlib.h"
#include <stdio.h>

const uint led = 25;

int main() {
    stdio_init_all();
    int counter = 0;
    gpio_init(led);
    gpio_set_dir(led, GPIO_OUT);
    printf("system clock initialized\n");
    while (true) {
        gpio_put(led, 1);
        sleep_ms(1000);
        gpio_put(led, 0);
        counter++;
        printf("studying for %i mins %i secs\n", (int)counter / 60, counter % 60);
    }
}